import flatpickr from 'flatpickr';
import './Flatpickr.scss';

export default flatpickr;
